# CityCare Sprint Plan
Naming format: **S0**, **R1-S01**, **R1-S02** ... **R2-S01** ... **R3-S10**.
| Sprint | Feature |
|---|---|
| S0 | Project planning and setup |
| R1-S01 | Core entities |
| R1-S02 | Validation |
| R1-S03 | People hierarchy |
| R1-S04 | Contracts and polymorphism |
| R1-S05 | Billing |
| R1-S06 | Hospital operations |
| R1-S07 | Errors and magic methods |
| R1-S08 | CLI and seed data |
| R2-S01 | Patient status and stays |
| R2-S02 | Payment strategies |
| R2-S03 | Doctor leave and notifications |
| R2-S04 | Appointment rules |
| R2-S05 | Discharge state machine |
| R2-S06 | ICU emergency |
| R2-S07 | Prescription safety |
| R2-S08 | Nurse coverage |
| R2-S09 | Command and audit |
| R2-S10 | Reports and iterators |
| R3-S01 | Laboratory |
| R3-S02 | Health packages |
| R3-S03 | Surgery |
| R3-S04 | Payroll |
| R3-S05 | Blood bank |
| R3-S06 | Bed lifecycle |
| R3-S07 | Ambulance |
| R3-S08 | Diet and visitors |
| R3-S09 | Referral and feedback |
| R3-S10 | Advanced search and timeline |

## Release tags
- `<your-name>-R1`
- `<your-name>-R2`
- `<your-name>-R3`
