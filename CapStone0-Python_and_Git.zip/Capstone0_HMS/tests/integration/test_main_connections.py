import unittest
from datetime import date

from hms.hospital import Hospital
from hms.main import load_seed
from hms.models import MRI


class TestMainConnections(unittest.TestCase):
    def test_appointment_lab_and_ambulance_reach_bill(self):
        h = Hospital()
        load_seed(h)

        h.book("P001", "D001", date.today(), "10:00")
        h.add_lab(MRI("T001", h.get_patient("P001"), h.get_doctor("D001"), True))
        h.dispatch_ambulance("Basic", 20, "P001")

        bill = h.make_bill("P001")
        names = [name for name, _ in bill.items]

        self.assertIn("Doctor Appointment - Dr. Meera Rao", names)
        self.assertIn("Test - MRI", names)
        self.assertIn("Ambulance", names)
        self.assertEqual(bill.total(), 7800)


if __name__ == "__main__":
    unittest.main()
