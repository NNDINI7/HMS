import unittest
#This is a test file for the billing services, it will test the total calculation of services.
class TestBillingServices(unittest.TestCase):
    def test_service_total(self):
        items = [("Doctor Appointment", 800), ("Test - MRI", 6500), ("Ambulance", 500)]
        self.assertEqual(sum(amount for _, amount in items), 7800)

if __name__ == "__main__":
    unittest.main()
