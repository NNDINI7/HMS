import unittest
#This is a test file for the CityCare acceptance flow, it will test the required steps in the flow.
class TestCityCareAcceptance(unittest.TestCase):
    def test_acceptance_flow_has_required_steps(self):
        steps = [
            "register patient",
            "book appointment",
            "book lab test",
            "book ambulance",
            "view bill",
        ]
        self.assertEqual(len(steps), 5)

if __name__ == "__main__":
    unittest.main()
