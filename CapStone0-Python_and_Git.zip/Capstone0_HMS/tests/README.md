# Testing

Run all tests:

```bash
python -m unittest discover -s tests -p "test_*.py" -v
```

Tests are grouped by release and sprint.
