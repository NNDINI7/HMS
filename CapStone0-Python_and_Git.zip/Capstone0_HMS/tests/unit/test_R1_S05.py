import unittest

class TestR1_S05(unittest.TestCase):
    """Basic test placeholder for Billing."""

    def test_sprint_is_registered(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
