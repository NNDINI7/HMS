import unittest

class TestR3_S01(unittest.TestCase):
    """Basic test placeholder for Laboratory."""

    def test_sprint_is_registered(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
