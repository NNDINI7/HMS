import unittest

class TestR1S01Core(unittest.TestCase):
    def test_basic_math(self):
        self.assertEqual(2 + 2, 4)

if __name__ == "__main__":
    unittest.main()
