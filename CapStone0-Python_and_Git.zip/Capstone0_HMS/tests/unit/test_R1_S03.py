import unittest

class TestR1_S03(unittest.TestCase):
    """Basic test placeholder for People hierarchy."""

    def test_sprint_is_registered(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
