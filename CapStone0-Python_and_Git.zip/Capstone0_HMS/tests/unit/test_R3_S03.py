import unittest

class TestR3_S03(unittest.TestCase):
    """Basic test placeholder for Surgery."""

    def test_sprint_is_registered(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
