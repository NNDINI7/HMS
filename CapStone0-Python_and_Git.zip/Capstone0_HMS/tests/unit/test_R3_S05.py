import unittest

class TestR3_S05(unittest.TestCase):
    """Basic test placeholder for Blood bank."""

    def test_sprint_is_registered(self):
        self.assertTrue(True)

if __name__ == "__main__":
    unittest.main()
