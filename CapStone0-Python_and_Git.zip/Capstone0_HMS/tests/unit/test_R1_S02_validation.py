import unittest
import re

class TestR1S02Validation(unittest.TestCase):
    def test_patient_id(self):
        self.assertRegex("P001", r"^P\d{3}$")
    def test_doctor_id(self):
        self.assertRegex("D001", r"^D\d{3}$")
    def test_phone(self):
        self.assertRegex("9876543210", r"^[6-9]\d{9}$")
    def test_age(self):
        self.assertTrue(0 <= 0 <= 120)
        self.assertTrue(0 <= 120 <= 120)

if __name__ == "__main__":
    unittest.main()
