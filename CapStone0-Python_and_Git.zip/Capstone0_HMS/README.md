# CityCare Hospital Management System

Simple Python 3.10+ terminal application for the CityCare capstone.

## Run the application

From the project root:

```bash
python main.py
```

The root `main.py` starts `hms.main`, so you do not need to change folders or edit Python paths.

## Run tests

Run an individual test:

```bash
python -m unittest tests.unit.test_R1_S01 -v
```

Run the acceptance test:

```bash
python -m unittest tests.acceptance.test_citycare_flow -v
```

## Main structure

- `main.py` - easy root launcher
- `hms/main.py` - terminal menu and user input
- `hms/models/` - one simple class per file
- `hms/hospital/` - hospital operations and billing connections
- `hms/validation/` - ID, name, age and phone validation
- `hms/exceptions/` - small custom error classes
- `hms/data/seed_data.py` - demo patients, doctors, nurses, wards and ambulances
- `tests/` - unit, integration and acceptance tests

## Important billing connection

Doctor appointments, lab tests and ambulance dispatches call the same `BillingService`. Therefore their charges are added to the patient's bill automatically.

Example bill:

- Doctor Appointment - Dr. Meera Rao - ₹800
- Test - MRI - ₹6,500
- Ambulance - ₹500
- Total - ₹7,800

The code is intentionally kept basic and readable so the classes and flow are easy to explain in a demo.
