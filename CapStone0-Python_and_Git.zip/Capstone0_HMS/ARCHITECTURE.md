# CityCare Architecture

Each main class is kept in its own Python file so it is easier to understand.

## Models
`hms/models/` contains Patient, Doctor, Nurse, Ward, Bill, Appointment, LabTest, MRI, ECG, Ambulance, Surgery, etc.

## Hospital
`hms/hospital/` contains the main Hospital class and separate service classes.

## Exceptions
`hms/exceptions/` contains one custom error per file.

## Validation
`hms/validation/` contains small validation files for IDs, names, phones, age and input helpers.

## Data
`hms/data/seed_data.py` contains sample Python data.

## Sprints
- S0 = planning
- R1-S01 ... R1-S08 = Release 1
- R2-S01 ... R2-S10 = Release 2
- R3-S01 ... R3-S10 = Release 3
