# S0 — Project Planning

This sprint is for planning before feature development.

## Work
- Read the rule book.
- Confirm Release 1, Release 2 and Release 3 scope.
- Create project folders.
- Create test structure.
- Prepare seed data.
- Prepare Git branch naming.
- Prepare acceptance checklist.

## Branch
`<your-name>/S0-planning`
