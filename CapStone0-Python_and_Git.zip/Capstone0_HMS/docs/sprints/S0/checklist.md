# S0 Planning Checklist

- [ ] Rule book reviewed
- [ ] Project structure created
- [ ] Seed data created
- [ ] Test folders created
- [ ] Sprint plan created
- [ ] Git workflow prepared
- [ ] Acceptance checklist prepared
