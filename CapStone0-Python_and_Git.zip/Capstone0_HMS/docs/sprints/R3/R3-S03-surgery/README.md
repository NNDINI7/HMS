# R3-S03 — Surgery

## Goal
Surgery

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R3-S03-surgery`
Tag: `<your-name>-r3-s03`

## Demo
Show the feature working from the terminal and show its test result.
