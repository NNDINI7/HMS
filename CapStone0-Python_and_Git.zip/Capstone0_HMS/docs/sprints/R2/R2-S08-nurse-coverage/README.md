# R2-S08 — Nurse coverage

## Goal
Nurse coverage

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R2-S08-nurse-coverage`
Tag: `<your-name>-r2-s08`

## Demo
Show the feature working from the terminal and show its test result.
