# R2-S07 — Prescription safety

## Goal
Prescription safety

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R2-S07-prescription-safety`
Tag: `<your-name>-r2-s07`

## Demo
Show the feature working from the terminal and show its test result.
