# R2-S03 — Doctor leave and notifications

## Goal
Doctor leave and notifications

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R2-S03-doctor-leave-and-notifications`
Tag: `<your-name>-r2-s03`

## Demo
Show the feature working from the terminal and show its test result.
