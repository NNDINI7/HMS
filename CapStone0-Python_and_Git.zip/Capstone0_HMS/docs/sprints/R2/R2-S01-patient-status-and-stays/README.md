# R2-S01 — Patient status and stays

## Goal
Patient status and stays

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R2-S01-patient-status-and-stays`
Tag: `<your-name>-r2-s01`

## Demo
Show the feature working from the terminal and show its test result.
