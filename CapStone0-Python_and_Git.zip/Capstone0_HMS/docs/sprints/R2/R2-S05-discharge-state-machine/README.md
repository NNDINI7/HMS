# R2-S05 — Discharge state machine

## Goal
Discharge state machine

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R2-S05-discharge-state-machine`
Tag: `<your-name>-r2-s05`

## Demo
Show the feature working from the terminal and show its test result.
