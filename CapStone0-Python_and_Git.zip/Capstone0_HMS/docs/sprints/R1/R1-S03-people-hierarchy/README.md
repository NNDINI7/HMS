# R1-S03 — People hierarchy

## Goal
People hierarchy

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R1-S03-people-hierarchy`
Tag: `<your-name>-r1-s03`

## Demo
Show the feature working from the terminal and show its test result.
