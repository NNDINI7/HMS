# R1-S05 Checklist

- [ ] Code complete
- [ ] Unit test added
- [ ] Integration test added if needed
- [ ] Invalid case tested
- [ ] Boundary case tested
- [ ] Test passes
- [ ] Commit created
- [ ] Branch pushed
- [ ] Pull request created
- [ ] Sprint tag created
