# R1-S07 — Errors and magic methods

## Goal
Errors and magic methods

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R1-S07-errors-and-magic-methods`
Tag: `<your-name>-r1-s07`

## Demo
Show the feature working from the terminal and show its test result.
