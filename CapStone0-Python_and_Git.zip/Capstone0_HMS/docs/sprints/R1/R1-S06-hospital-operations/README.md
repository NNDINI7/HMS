# R1-S06 — Hospital operations

## Goal
Hospital operations

## Work
- Implement this feature in small commits.
- Keep code simple and easy to explain.
- Add unit tests.
- Add integration tests if multiple classes are involved.
- Update documentation when needed.

## Testing
- Happy path
- Invalid input
- Boundary case
- Expected exception
- Regression test

## Git
Branch: `<your-name>/R1-S06-hospital-operations`
Tag: `<your-name>-r1-s06`

## Demo
Show the feature working from the terminal and show its test result.
