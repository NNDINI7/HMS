"""Easy launcher: run `python main.py` from the project root."""

from hms.main import main


if __name__ == "__main__":
    main()
