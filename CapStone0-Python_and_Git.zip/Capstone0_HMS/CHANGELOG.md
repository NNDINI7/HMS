# Changelog

## Current fix
- Added a root `main.py` launcher.
- Connected the individual model classes with the Hospital service.
- Fixed package imports so the application runs from the project root.
- Added seed data for patients, doctors, nurses, wards and ambulances.
- Connected appointment, lab and ambulance charges to patient bills.
- Added readable bill line items such as `Test - MRI` and `Ambulance`.
- Kept validation and custom errors in separate folders.
