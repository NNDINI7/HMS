"""Lab booking helper."""

from .billing_service import BillingService


class LabService:
    def __init__(self, hospital):
        self.hospital = hospital

    def book(self, pid, test):
        self.hospital.lab[test.tid] = test
        names = {"BloodTest": "Blood Test", "XRay": "X-Ray", "MRI": "MRI", "ECG": "ECG"}
        nm = names.get(test.__class__.__name__, test.__class__.__name__)
        BillingService(self.hospital).add_charge(pid, f"Test - {nm}", test.price())
        return test
