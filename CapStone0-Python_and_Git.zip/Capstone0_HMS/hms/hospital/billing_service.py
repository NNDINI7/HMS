"""Small billing helper used by the Hospital class."""

from ..models import Bill


class BillingService:
    def __init__(self, hospital):
        self.hospital = hospital

    def get_bill(self, pid):
        if pid not in self.hospital.bills:
            self.hospital.bills[pid] = Bill(f"B{len(self.hospital.bills) + 1:03d}", pid)
        return self.hospital.bills[pid]

    def add_charge(self, pid, name, amount):
        bill = self.get_bill(pid)
        bill.add_item(name, amount)
        return bill
