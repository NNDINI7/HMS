"""Main CityCare hospital service.

The class keeps the data in memory and connects the small model classes.
"""

from datetime import date, datetime, timedelta

from ..models import (
    Appointment, Ambulance, Bill, BloodTest, Doctor, ECG, HealthPackage,
    MRI, Nurse, Patient, Receptionist, SeniorDoctor, Surgery, XRay, Ward
)
from ..exceptions import (
    AppointmentError, BedNotAvailableError, BillingError,
    DoctorNotAvailableError, HospitalError, PatientNotFoundError
)
from .billing_service import BillingService
from .appointment_service import AppointmentService
from .ambulance_service import AmbulanceService
from .lab_service import LabService


class Hospital:
    HOSPITAL_NAME = "CityCare Hospital"

    def __init__(self, name=None):
        self.name = name or self.HOSPITAL_NAME
        self.patients = {}
        self.staff = {}
        self.doctors_map = {}
        self.nurses = {}
        self.appointments = {}
        self.bills = {}
        self.wards = {}
        self.lab = {}
        self.packages = {}
        self.surgeries = {}
        self.ambulances = []
        self.blood_bank = {g: [] for g in ("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-")}
        self.audit = []
        self.next_patient = 1
        self.next_appointment = 1
        self.next_surgery = 1
        self.next_test = 1

    # ---------- basic registration ----------
    def add_patient(self, patient):
        self.patients[patient.pid.upper()] = patient
        self._log(f"Registered patient {patient.pid}")
        return patient

    def add_doctor(self, doctor):
        self.staff[doctor.pid.upper()] = doctor
        self.doctors_map[doctor.pid.upper()] = doctor
        self._log(f"Added doctor {doctor.pid}")
        return doctor

    def add_nurse(self, nurse):
        self.staff[nurse.pid.upper()] = nurse
        self.nurses[nurse.pid.upper()] = nurse
        return nurse

    def add_receptionist(self, rec):
        self.staff[rec.pid.upper()] = rec
        return rec

    def add_staff(self, staff):
        if isinstance(staff, Nurse):
            return self.add_nurse(staff)
        if isinstance(staff, Doctor):
            return self.add_doctor(staff)
        if isinstance(staff, Receptionist):
            return self.add_receptionist(staff)
        self.staff[staff.pid.upper()] = staff
        return staff

    def doctors(self):
        return list(self.doctors_map.values())

    def patients_list(self):
        return list(self.patients.values())

    def get_patient(self, pid):
        p = self.patients.get(pid.upper())
        if not p:
            raise PatientNotFoundError(f"Patient {pid.upper()} was not found.")
        return p

    def get_doctor(self, did):
        d = self.doctors_map.get(did.upper())
        if not d:
            raise HospitalError(f"Doctor {did.upper()} was not found.")
        return d

    # ---------- appointments ----------
    def book(self, pid, did, day, tm):
        p = self.get_patient(pid)
        d = self.get_doctor(did)
        if day in d.leave_dates:
            raise DoctorNotAvailableError(f"Dr. {d.name} is on leave on {day}.")
        if tm not in d.available_slots:
            raise DoctorNotAvailableError(f"Dr. {d.name} is not available at {tm}.")
        if not AppointmentService(self).is_free(d.pid, day, tm):
            raise DoctorNotAvailableError(f"Dr. {d.name} is already booked at {tm}.")
        aid = f"A{self.next_appointment:03d}"
        self.next_appointment += 1
        ap = Appointment(aid, p.pid, d.pid, day, tm)
        ap.paid = d.fee
        self.appointments[aid] = ap
        p.doctor_id = d.pid
        p.add_history(f"Appointment {aid} with Dr. {d.name} on {day} at {tm}")
        d.consultations += 1
        BillingService(self).add_charge(p.pid, f"Doctor Appointment - Dr. {d.name}", d.fee)
        self._log(f"Booked {aid}")
        return ap

    def cancel(self, aid):
        ap = self.appointments.get(aid.upper())
        if not ap:
            raise AppointmentError(f"Appointment {aid.upper()} was not found.")
        if ap.status != "BOOKED":
            raise AppointmentError("Only a booked appointment can be cancelled.")
        ap.status = "CANCELLED"
        refund = ap.paid
        ap.paid = 0
        self._log(f"Cancelled {aid}")
        return refund

    def doctor_leave(self, did, day):
        d = self.get_doctor(did)
        if day not in d.leave_dates:
            d.leave_dates.append(day)
        for ap in self.appointments.values():
            if ap.did == d.pid and ap.date == day and ap.status == "BOOKED":
                others = [x for x in self.doctors() if x.speciality == d.speciality and x.pid != d.pid and day not in x.leave_dates]
                moved = False
                for other in others:
                    for tm in other.available_slots:
                        if AppointmentService(self).is_free(other.pid, day, tm):
                            ap.did = other.pid
                            ap.time = tm
                            moved = True
                            break
                    if moved:
                        break
                if not moved:
                    ap.status = "RESCHEDULE_PENDING"
        return d

    # ---------- wards ----------
    def admit(self, pid, ward_name):
        p = self.get_patient(pid)
        ward = next((w for w in self.wards.values() if w.name.lower() == ward_name.strip().lower()), None)
        if ward is None:
            raise BedNotAvailableError(f"Ward {ward_name} does not exist.")
        if ward.is_full():
            raise BedNotAvailableError(f"{ward.name} ward is full ({ward.occupied}/{ward.beds} beds occupied).")
        if p.ward:
            raise HospitalError("Patient is already admitted.")
        ward.occupied += 1
        p.status = "IPD"
        p.ward = ward.name
        p.bed_id = f"{ward.name[:2].upper()}{ward.occupied:02d}"
        p.admission_date = date.today()
        p.add_history(f"Admitted to {ward.name}, bed {p.bed_id}")
        self._log(f"Admitted {pid} to {ward.name}")
        return p

    def transfer(self, pid, ward_name):
        p = self.get_patient(pid)
        if not p.ward:
            raise HospitalError("Patient is not currently admitted.")
        old = self.wards[p.ward]
        new = next((w for w in self.wards.values() if w.name.lower() == ward_name.strip().lower()), None)
        if new is None:
            raise BedNotAvailableError(f"Ward {ward_name} does not exist.")
        if new.is_full():
            raise BedNotAvailableError(f"{new.name} ward is full.")
        old.occupied -= 1
        new.occupied += 1
        p.ward = new.name
        p.bed_id = f"{new.name[:2].upper()}{new.occupied:02d}"
        p.add_history(f"Transferred to {new.name}, bed {p.bed_id}")
        return p

    def discharge(self, pid):
        p = self.get_patient(pid)
        if not p.ward:
            raise HospitalError("Patient is not admitted.")
        self.wards[p.ward].occupied -= 1
        p.add_history(f"Discharged from {p.ward}")
        p.ward = None
        p.bed_id = None
        p.status = "OPD"
        return p

    def occupancy(self):
        return {w.name: {"AVAILABLE": w.available(), "OCCUPIED": w.occupied, "CLEANING": w.cleaning, "MAINTENANCE": w.maintenance} for w in self.wards.values()}

    def bed_report(self):
        return [f"{w.name}: available={w.available()}, occupied={w.occupied}, cleaning={w.cleaning}, maintenance={w.maintenance}" for w in self.wards.values()]

    # ---------- prescriptions and bills ----------
    def add_prescription(self, pid, med, cat):
        p = self.get_patient(pid)
        for old in p.prescriptions:
            if old["medicine"].lower() == med.lower() and old["category"].lower() == cat.lower():
                raise HospitalError("Same medicine already exists in the current prescription.")
        if cat.lower() in {x.lower() for x in p.allergies}:
            raise HospitalError(f"Patient is allergic to {cat}.")
        p.prescriptions.append({"medicine": med, "category": cat, "date": date.today()})
        p.add_history(f"Prescription: {med}")
        BillingService(self).add_charge(p.pid, f"Medicine - {med}", 50)

    def make_bill(self, pid):
        p = self.get_patient(pid)
        bill = BillingService(self).get_bill(p.pid)
        # Add IPD stay charges once per bill generation.
        if p.ward and not any(x[0] == "Ward stay" for x in bill.items):
            days = max(1, (date.today() - (p.admission_date or date.today())).days)
            ward = self.wards[p.ward]
            bill.add_item("Ward stay", days * ward.charge)
            bill.add_item("Service tax (5%)", bill.total() * 0.05)
        if p.age >= 60 and not any(x[0] == "Senior citizen discount" for x in bill.items):
            discount = bill.total() * 0.10
            bill.add_item("Senior citizen discount", -discount)
        return bill

    def claim(self, bid, typ):
        bill = next((b for b in self.bills.values() if b.bid.upper() == bid.upper()), None)
        if not bill:
            raise BillingError(f"Bill {bid.upper()} was not found.")
        rules = {
            "SELF-PAY": 1.0,
            "GOVERNMENT SCHEME": 0.0,
            "PRIVATE INSURANCE": 0.20,
            "CORPORATE TIE-UP": 0.30,
        }
        key = typ.strip().upper()
        if key not in rules:
            raise BillingError("Unknown payment policy.")
        insurer = bill.total() * (1 - rules[key])
        patient = bill.total() - insurer
        bill.add_item(f"Patient payable ({key})", patient)
        return patient

    # ---------- lab and packages ----------
    def add_lab(self, test):
        if isinstance(test, MRI) and not test.approved:
            raise HospitalError("MRI requires doctor's approval before scheduling.")
        if not test.patient:
            raise HospitalError("Lab test needs a patient.")
        LabService(self).book(test.patient.pid, test)
        test.patient.add_history(f"Lab test {test.__class__.__name__} booked")
        return test

    def package(self, name, tids):
        p = HealthPackage(name)
        for tid in tids:
            if tid in self.lab:
                p.add(self.lab[tid])
        self.packages[name] = p
        return p

    # ---------- surgery ----------
    def schedule_surgery(self, pid, kind, day, tm):
        p = self.get_patient(pid)
        kind = kind.upper()
        if kind == "MAJOR" and p.status != "IPD":
            raise HospitalError("Only an IPD patient can have Major surgery.")
        sid = f"S{self.next_surgery:03d}"
        self.next_surgery += 1
        s = Surgery(sid, pid, kind, day, tm, theatre="OT1")
        for old in self.surgeries.values():
            if old.date == day and old.time == tm and old.theatre == s.theatre:
                raise HospitalError(f"ResourceConflictError: theatre {s.theatre} is already booked.")
        self.surgeries[sid] = s
        BillingService(self).add_charge(pid, f"Surgery - {kind}", s.price())
        p.add_history(f"Surgery {sid}: {kind}")
        return s

    # ---------- payroll ----------
    def payroll(self, month):
        rows = []
        for st in self.staff.values():
            if isinstance(st, Doctor):
                gross = 80000 + st.consultations * 200 + st.surgeries * 2000
            elif isinstance(st, Nurse):
                gross = 30000 + st.night_shifts * 500
            elif isinstance(st, Receptionist):
                gross = 22000 + st.overtime * 150
            else:
                continue
            tax = gross * 0.10 if gross > 50000 else 0
            rows.append(f"{st.pid} {st.name}: Gross ₹{gross:,.0f} | Tax ₹{tax:,.0f} | Net ₹{gross-tax:,.0f}")
        return rows

    # ---------- blood ----------
    def add_blood(self, group, collected=None, units=1):
        self.blood_bank[group.upper()].extend([collected or date.today()] * int(units))

    @staticmethod
    def can_give(donor, receiver):
        rules = {
            "O-": ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"],
            "O+": ["A+", "B+", "AB+", "O+"],
            "A-": ["A+", "A-", "AB+", "AB-"],
            "A+": ["A+", "AB+"],
            "B-": ["B+", "B-", "AB+", "AB-"],
            "B+": ["B+", "AB+"],
            "AB-": ["AB+", "AB-"],
            "AB+": ["AB+"],
        }
        return receiver in rules.get(donor, [])

    def blood_issue(self, pid, bg, units):
        p = self.get_patient(pid)
        bg = bg.upper()
        candidates = []
        for donor, dates in self.blood_bank.items():
            if self.can_give(donor, bg):
                for d in dates:
                    if (date.today() - d).days <= 42:
                        candidates.append((d, donor))
        candidates.sort()
        if len(candidates) < units:
            raise HospitalError("BloodUnavailableError: no compatible unexpired units are available.")
        for _, donor in candidates[:units]:
            self.blood_bank[donor].remove(_)
        BillingService(self).add_charge(pid, "Blood units", units * 1000)
        p.add_history(f"Received {units} unit(s) of blood")

    # ---------- ambulance ----------
    def dispatch_ambulance(self, kind, km, pid):
        p = self.get_patient(pid)
        options = [a for a in self.ambulances if a.available and a.kind.upper() == kind.upper()]
        if not options:
            raise HospitalError(f"No {kind} ambulance is available.")
        a = min(options, key=lambda x: x.distance if x.distance else km)
        a.distance = km
        a, charge = AmbulanceService(self).book(p.pid, a, km)
        p.add_history(f"Ambulance {a.aid} arrived; charge ₹{charge:.0f}")
        return a

    # ---------- diet and visitors ----------
    def set_diet(self, pid, diet):
        p = self.get_patient(pid)
        if p.status != "IPD":
            raise HospitalError("Diet can be set only for an inpatient.")
        prices = {"REGULAR": 300, "DIABETIC": 400, "LIQUID": 250, "LOW-SALT": 350}
        key = diet.upper()
        if key not in prices:
            raise HospitalError("Invalid diet plan.")
        p.diet = key
        BillingService(self).add_charge(pid, f"Diet - {key}", prices[key])

    def add_visitor(self, pid, name, when, approved=False):
        p = self.get_patient(pid)
        if p.status != "IPD":
            raise HospitalError("Visitors are allowed only for inpatients.")
        if not (16 <= when.hour < 19):
            raise HospitalError("VisitorPolicyError: visiting hours are 16:00-19:00.")
        if len(p.visitors) >= 2:
            raise HospitalError("VisitorPolicyError: maximum 2 visitors at a time.")
        if p.ward == "ICU" and not approved:
            raise HospitalError("VisitorPolicyError: ICU visit needs doctor's approval.")
        p.visitors.append(name)

    # ---------- referrals, follow-ups and ratings ----------
    def refer(self, pid, speciality):
        p = self.get_patient(pid)
        d = next((x for x in self.doctors() if x.speciality.lower() == speciality.lower()), None)
        if not d:
            raise HospitalError("No doctor found for that speciality.")
        p.add_history(f"Referral to {speciality}")
        return self.book(p.pid, d.pid, date.today(), d.available_slots[0])

    def add_followup(self, aid, day):
        ap = self.appointments.get(aid.upper())
        if not ap:
            raise AppointmentError("Appointment not found.")
        ap.status = "COMPLETED"
        ap.followup = day
        self.get_patient(ap.pid).followups.append((day, ap.did))

    def followups_due(self):
        end = date.today() + timedelta(days=7)
        return [(p.pid, p.name, d, did) for p in self.patients.values() for d, did in p.followups if date.today() <= d <= end]

    def rate_doctor(self, aid, rating):
        ap = self.appointments.get(aid.upper())
        if not ap or ap.status != "COMPLETED":
            raise HospitalError("Rating is allowed only after a completed appointment.")
        if aid.upper() in {str(x) for x in self.get_patient(ap.pid).ratings}:
            raise HospitalError("Only one rating is allowed for an appointment.")
        if not 1 <= rating <= 5:
            raise HospitalError("Rating must be from 1 to 5.")
        self.get_doctor(ap.did).ratings.append(rating)
        self.get_patient(ap.pid).ratings.add(aid.upper())

    # ---------- search and timeline ----------
    def search(self, text):
        text = text.strip().lower()
        return [p for p in self.patients.values() if text in p.pid.lower() or text in p.name.lower()]

    def advanced_search(self, name="", bg="", kind="", doctor=""):
        result = list(self.patients.values())
        if name:
            result = [p for p in result if name.lower() in p.name.lower()]
        if bg:
            result = [p for p in result if p.blood_group.upper() == bg.upper()]
        if kind:
            result = [p for p in result if p.status.upper() == kind.upper()]
        if doctor:
            result = [p for p in result if p.doctor_id == doctor.upper()]
        return result

    def timeline(self, pid):
        p = self.get_patient(pid)
        events = [(str(p.admission_date or date.today()), x) for x in p.history]
        for a in self.appointments.values():
            if a.pid == p.pid:
                events.append((str(a.date), f"Appointment {a.aid}: {a.status}"))
        for t in self.lab.values():
            if t.patient and t.patient.pid == p.pid:
                events.append((str(date.today()), f"Lab: {t.__class__.__name__}"))
        for s in self.surgeries.values():
            if s.pid == p.pid:
                events.append((str(s.date), f"Surgery: {s.kind}"))
        for name, amount in self.bills.get(p.pid, Bill("x", p.pid)).items:
            events.append((str(date.today()), f"Bill: {name} ₹{amount}"))
        for item in sorted(events, key=lambda x: x[0]):
            yield item

    # ---------- reports ----------
    def revenue_report(self):
        total = sum(b.total() for b in self.bills.values())
        return f"₹{total:,.2f}"

    def doctor_earnings(self):
        rows = []
        for d in sorted(self.doctors(), key=lambda x: x.fee * x.consultations, reverse=True):
            rows.append(f"{d.name}: ₹{d.fee * d.consultations:,.2f} (rating {d.average_rating:.1f})")
        return rows

    def undo(self):
        for aid in reversed(list(self.appointments)):
            ap = self.appointments[aid]
            if ap.status == "BOOKED":
                ap.status = "CANCELLED"
                return f"Undid booking {aid}."
        return "Nothing to undo."

    def _log(self, text):
        self.audit.append((datetime.now(), text))

    @staticmethod
    def is_valid_phone(phone):
        return phone.isdigit() and len(phone) == 10
