"""Ambulance booking helper."""

from .billing_service import BillingService


class AmbulanceService:
    def __init__(self, hospital):
        self.hospital = hospital

    def book(self, pid, ambulance, km):
        charge = ambulance.charge(km)
        ambulance.available = False
        BillingService(self.hospital).add_charge(pid, "Ambulance", charge)
        return ambulance, charge
