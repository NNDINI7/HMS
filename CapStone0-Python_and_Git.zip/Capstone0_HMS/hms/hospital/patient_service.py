"""Patient helper."""

class PatientService:
    def __init__(self, hospital):
        self.hospital = hospital

    def admit(self, pid):
        return self.hospital.admit(pid, "General")
