"""Appointment helper."""

class AppointmentService:
    def __init__(self, hospital):
        self.hospital = hospital

    def is_free(self, did, day, tm):
        return not any(
            a.did == did and a.date == day and a.time == tm and a.status == "BOOKED"
            for a in self.hospital.appointments.values()
        )
