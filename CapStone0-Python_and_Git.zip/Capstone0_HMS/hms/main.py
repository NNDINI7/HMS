"""Simple terminal menu for CityCare Hospital."""

from datetime import date, datetime

from .data import SEED_DATA
from .hospital import Hospital
from .models import (
    Ambulance, BloodTest, Doctor, ECG, MRI, Nurse, Patient,
    Receptionist, SeniorDoctor, Ward, XRay
)
from .exceptions import CityCareError
from .validation import get_age, get_id, get_name, get_phone


def load_seed(h):
    """Load small sample data once when the program starts."""
    for x in SEED_DATA["patients"]:
        h.add_patient(Patient(x["id"], x["name"], x["age"], x["phone"], x["blood"]))

    for x in SEED_DATA["doctors"]:
        cls = SeniorDoctor if x["id"] == "D001" else Doctor
        h.add_staff(cls(x["id"], x["name"], x["age"], x["phone"], x["speciality"], x["fee"]))

    for x in SEED_DATA["nurses"]:
        h.add_staff(Nurse(x["id"], x["name"], x["age"], x["phone"], x["shift"], x["ward"]))

    h.add_staff(Receptionist("R001", "Anil", 35, "9876500020"))

    for x in SEED_DATA["wards"]:
        h.wards[x["name"]] = Ward(x["name"], x["beds"], x["charge"])

    for x in SEED_DATA["ambulances"]:
        h.ambulances.append(Ambulance(x["id"], x["kind"], x["distance"]))

    # A few blood units for demo/testing.
    h.add_blood("O-", units=3)
    h.add_blood("A+", units=2)


def menu():
    print("""
========== CityCare Hospital Management ==========
 1. Register patient
 2. Add doctor / nurse / receptionist
 3. View doctors
 4. View patients
 5. Search patient
 6. Book doctor appointment
 7. Cancel appointment
 8. Admit patient
 9. Discharge patient
10. Add prescription
11. View patient bill
12. Ward occupancy
13. View all bills by amount
14. Transfer patient
15. Insurance claim
16. Doctor leave / reschedule
17. Book lab test
18. Health package
19. Schedule surgery
20. Payroll
21. Blood bank
22. Ambulance dispatch
23. Diet / visitor
24. Referral / follow-up / rating
25. Advanced search
26. Patient timeline
27. Reports
28. Undo last booking
 0. Exit
==================================================""")


def patient_id():
    return get_id("Patient ID", "P")


def doctor_id():
    return get_id("Doctor ID", "D")


def main():
    h = Hospital()
    load_seed(h)

    while True:
        menu()
        choice = input("Enter choice: ").strip()

        if not choice.isdigit():
            print("Invalid choice")
            continue

        try:
            choice = int(choice)
            if choice == 0:
                print("Goodbye!")
                return

            if choice == 1:
                name = get_name()
                age = get_age()
                phone = get_phone()
                bg = input("Blood group: ").strip().upper()
                p = Patient(f"P{h.next_patient:03d}", name, age, phone, bg)
                h.next_patient += 1
                h.add_patient(p)
                print(f"Patient registered successfully. Patient ID: {p.pid}")

            elif choice == 2:
                typ = input("Type (doctor/nurse/receptionist): ").strip().lower()
                if typ == "doctor":
                    sid = get_id("Doctor ID", "D")
                    name = get_name("Doctor name")
                    age = get_age()
                    phone = get_phone()
                    spec = input("Specialisation: ").strip()
                    fee = float(input("Consultation fee: "))
                    h.add_doctor(Doctor(sid, name, age, phone, spec, fee))
                elif typ == "nurse":
                    sid = get_id("Nurse ID", "N")
                    name = get_name("Nurse name")
                    age = get_age()
                    phone = get_phone()
                    shift = input("Shift (Morning/Evening/Night): ").strip()
                    ward = input("Ward: ").strip().title()
                    h.add_nurse(Nurse(sid, name, age, phone, shift, ward))
                elif typ == "receptionist":
                    sid = get_id("Receptionist ID", "R")
                    name = get_name("Receptionist name")
                    age = get_age()
                    phone = get_phone()
                    h.add_receptionist(Receptionist(sid, name, age, phone))
                else:
                    print("Invalid staff type")
                    continue
                print("Staff added successfully.")

            elif choice == 3:
                print("\nDoctors")
                for d in h.doctors():
                    print(f"{d.pid} | {d.name} | {d.speciality} | ₹{d.fee:.0f} | Rating {d.average_rating:.1f}")

            elif choice == 4:
                print("\nPatients")
                for p in h.patients_list():
                    print(f"{p.pid} | {p.name} | {p.status} | {p.blood_group}")

            elif choice == 5:
                for p in h.search(input("Patient ID or name: ")):
                    print(p.pid, p.name, p.status, p.blood_group)

            elif choice == 6:
                pid = patient_id()
                did = doctor_id()
                d = h.get_doctor(did)
                print("Available slots:", ", ".join(d.available_slots))
                day = date.fromisoformat(input("Date YYYY-MM-DD: "))
                tm = input("Time HH:MM: ").strip()
                ap = h.book(pid, did, day, tm)
                print(f"Appointment {ap.aid} booked successfully.")

            elif choice == 7:
                aid = get_id("Appointment ID", "A")
                print(f"Refund: ₹{h.cancel(aid):.2f}")

            elif choice == 8:
                pid = patient_id()
                ward = input("Ward (General/Private/ICU): ").strip()
                p = h.admit(pid, ward)
                print(f"Admitted to {p.ward}, bed {p.bed_id}.")

            elif choice == 9:
                pid = patient_id()
                print("Discharge approved by senior doctor for demo.")
                p = h.discharge(pid)
                print(f"{p.name} discharged successfully.")

            elif choice == 10:
                pid = patient_id()
                med = input("Medicine name: ").strip()
                cat = input("Medicine category/allergy group: ").strip()
                h.add_prescription(pid, med, cat)
                print("Prescription added and medicine charge added to bill.")

            elif choice == 11:
                pid = patient_id()
                h.make_bill(pid).show_details()

            elif choice == 12:
                for ward, data in h.occupancy().items():
                    print(f"{ward}: {data}")

            elif choice == 13:
                bills = sorted(h.bills.values(), reverse=True)
                if not bills:
                    print("No bills yet.")
                for b in bills:
                    print(f"\n{b.bid} | Patient {b.pid}")
                    for name, amount in b.items:
                        print(f"  {name}: ₹{amount:,.2f}")
                    print(f"  TOTAL: ₹{b.total():,.2f}")

            elif choice == 14:
                pid = patient_id()
                ward = input("New ward: ").strip()
                p = h.transfer(pid, ward)
                print(f"Transferred to {p.ward}, bed {p.bed_id}.")

            elif choice == 15:
                bid = get_id("Bill ID", "B")
                typ = input("Payment policy (Self-pay/Government scheme/Private insurance/Corporate tie-up): ")
                print(f"Patient payable: ₹{h.claim(bid, typ):,.2f}")

            elif choice == 16:
                did = doctor_id()
                day = date.fromisoformat(input("Leave date YYYY-MM-DD: "))
                h.doctor_leave(did, day)
                print("Leave recorded. Matching appointments were moved when possible.")

            elif choice == 17:
                pid = patient_id()
                did = doctor_id()
                typ = input("Test (BloodTest/XRay/MRI/ECG): ").strip().lower()
                tid = f"T{h.next_test:03d}"
                h.next_test += 1
                p, d = h.get_patient(pid), h.get_doctor(did)
                if typ == "bloodtest":
                    t = BloodTest(tid, p, d)
                elif typ == "xray":
                    t = XRay(tid, p, d)
                elif typ == "mri":
                    ok = input("Doctor approved MRI? (y/n): ").strip().lower() == "y"
                    t = MRI(tid, p, d, ok)
                elif typ == "ecg":
                    t = ECG(tid, p, d)
                else:
                    print("Invalid test")
                    continue
                h.add_lab(t)
                print(f"{tid} booked. Charge: ₹{t.price():,.2f}")

            elif choice == 18:
                name = input("Package (Basic/Executive/Senior Citizen): ").strip()
                tids = [x.strip().upper() for x in input("Test IDs separated by comma: ").split(",") if x.strip()]
                p = h.package(name, tids)
                print(f"Package price: ₹{p.price():,.2f}")

            elif choice == 19:
                pid = patient_id()
                kind = input("Surgery (Minor/Major/Emergency): ").strip()
                day = date.fromisoformat(input("Date YYYY-MM-DD: "))
                tm = input("Time HH:MM: ").strip()
                s = h.schedule_surgery(pid, kind, day, tm)
                print(f"Surgery {s.sid} booked. Charge: ₹{s.price():,.2f}")

            elif choice == 20:
                month = input("Month (e.g. October): ").strip()
                for row in h.payroll(month):
                    print(row)

            elif choice == 21:
                action = input("Add or Issue? ").strip().lower()
                if action == "add":
                    bg = input("Donor blood group: ").strip().upper()
                    units = int(input("Units: "))
                    h.add_blood(bg, units=units)
                    print("Blood units added.")
                else:
                    pid = patient_id()
                    bg = input("Patient blood group: ").strip().upper()
                    units = int(input("Units: "))
                    h.blood_issue(pid, bg, units)
                    print("Blood issued and charge added to bill.")

            elif choice == 22:
                kind = input("Ambulance (Basic/ALS): ").strip()
                km = float(input("Distance in km: "))
                pid = patient_id()
                a = h.dispatch_ambulance(kind, km, pid)
                print(f"{a.aid} dispatched. Charge: ₹{a.charge(km):,.2f}")

            elif choice == 23:
                pid = patient_id()
                typ = input("diet or visitor: ").strip().lower()
                if typ == "diet":
                    h.set_diet(pid, input("Diet (Regular/Diabetic/Liquid/Low-salt): "))
                    print("Diet updated and charge added.")
                else:
                    name = get_name("Visitor name")
                    approved = input("Doctor approved? (y/n): ").strip().lower() == "y"
                    h.add_visitor(pid, name, datetime.now(), approved)
                    print("Visitor added.")

            elif choice == 24:
                typ = input("refer / followup / rating: ").strip().lower()
                if typ == "refer":
                    pid = patient_id()
                    spec = input("Specialisation: ").strip()
                    print(h.refer(pid, spec))
                elif typ == "followup":
                    aid = get_id("Appointment ID", "A")
                    day = date.fromisoformat(input("Follow-up date YYYY-MM-DD: "))
                    h.add_followup(aid, day)
                    print("Follow-up saved.")
                    print("Due soon:", h.followups_due())
                else:
                    aid = get_id("Completed appointment ID", "A")
                    rating = int(input("Rating 1-5: "))
                    h.rate_doctor(aid, rating)
                    print("Rating saved.")

            elif choice == 25:
                name = input("Name partial (blank = any): ")
                bg = input("Blood group (blank = any): ")
                kind = input("OPD/IPD (blank = any): ").upper()
                did = input("Doctor ID (blank = any): ").upper()
                for p in h.advanced_search(name, bg, kind, did):
                    print(p.pid, p.name, p.status, p.blood_group)

            elif choice == 26:
                pid = patient_id()
                for when, text in h.timeline(pid):
                    print(when, "-", text)

            elif choice == 27:
                print("Daily revenue:", h.revenue_report())
                print("Doctor earnings:")
                for row in h.doctor_earnings():
                    print(" ", row)
                print("Ward report:")
                for row in h.bed_report():
                    print(" ", row)

            elif choice == 28:
                print(h.undo())

            else:
                print("Invalid choice")

        except CityCareError as e:
            print(f"Error: {e}")
        except (KeyError, ValueError) as e:
            print(f"Error: invalid input ({e})")
        except Exception as e:
            # Keeps the terminal app alive during a demo if an unexpected input slips through.
            print(f"Error: {e}")


if __name__ == "__main__":
    main()
