"""Ambulance model."""


class Ambulance:
    def __init__(self, aid, kind="Basic", distance=0):
        self.aid = aid
        self.kind = kind
        self.distance = float(distance)
        self.available = True

    @property
    def rate(self):
        return 15 if self.kind.upper() == "BASIC" else 40

    def charge(self, km=None):
        km = self.distance if km is None else float(km)
        return max(500, self.rate * km)

    def get_details(self):
        state = "AVAILABLE" if self.available else "ON_TRIP"
        return f"{self.aid} - {self.kind} - {state}"
