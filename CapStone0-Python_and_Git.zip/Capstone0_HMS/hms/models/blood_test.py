from .lab_test import LabTest


class BloodTest(LabTest):
    def __init__(self, tid, patient=None, doctor=None):
        super().__init__(tid, patient, doctor)

    def price(self):
        return 400

    def generate_report(self):
        return self.result or "haemoglobin, WBC, platelets with normal ranges"
