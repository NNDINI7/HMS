from .lab_test import LabTest


class XRay(LabTest):
    def __init__(self, tid, patient=None, doctor=None):
        super().__init__(tid, patient, doctor)

    def price(self):
        return 800

    def generate_report(self):
        return self.result or "body part, findings text"
