"""Patient bill with simple line items."""


class Bill:
    def __init__(self, bid, pid):
        self.bid = bid
        self.pid = pid
        self.items = []
        self.paid = 0.0

    def add_item(self, name, amount):
        self.items.append((name, float(amount)))

    def total(self):
        return sum(amount for _, amount in self.items)

    def balance(self):
        return self.total() - self.paid

    def pay(self, amount=None):
        self.paid = self.total() if amount is None else min(float(amount), self.total())

    def __lt__(self, other):
        return self.total() < other.total()

    def __add__(self, other):
        return self.total() + other.total()

    def show_details(self):
        print(f"\n----- Bill {self.bid} for {self.pid} -----")
        if not self.items:
            print("No charges yet.")
        for name, amount in self.items:
            print(f"{name:<35} ₹{amount:,.2f}")
        print(f"Total:                              ₹{self.total():,.2f}")
        print(f"Paid:                               ₹{self.paid:,.2f}")
        print(f"Balance:                            ₹{self.balance():,.2f}")
