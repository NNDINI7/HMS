"""Simple surgery model."""


class Surgery:
    CHARGES = {"MINOR": 15000, "MAJOR": 60000, "EMERGENCY": 80000}

    def __init__(self, sid, pid, kind, date, time, surgeon=None, anaesthetist=None, nurses=None, theatre="OT1"):
        self.sid = sid
        self.pid = pid
        self.kind = kind.upper()
        self.date = date
        self.time = time
        self.surgeon = surgeon
        self.anaesthetist = anaesthetist
        self.nurses = nurses or []
        self.theatre = theatre

    def price(self):
        return self.CHARGES.get(self.kind, 15000)
