"""Base class for laboratory tests."""

from abc import ABC, abstractmethod


class LabTest(ABC):
    def __init__(self, tid, patient=None, doctor=None, status="ORDERED"):
        self.tid = tid
        self.patient = patient
        self.doctor = doctor
        self.status = status
        self.result = None
        self.abnormal = False

    @abstractmethod
    def price(self):
        pass

    @abstractmethod
    def generate_report(self):
        pass

    def add_result(self, result, abnormal=False):
        self.result = result
        self.abnormal = abnormal
        self.status = "COMPLETED"
