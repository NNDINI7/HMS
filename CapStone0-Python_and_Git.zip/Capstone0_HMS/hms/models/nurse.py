"""Nurse model."""

from .person import Person


class Nurse(Person):
    def __init__(self, nid, name, age, phone, shift="Morning", ward="General"):
        super().__init__(nid, name, age, phone)
        self.shift = shift
        self.ward = ward
        self.night_shifts = 0

    def get_role(self):
        return "Nurse"
