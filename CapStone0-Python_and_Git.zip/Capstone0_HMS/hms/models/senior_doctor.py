"""Senior doctor model."""

from .doctor import Doctor


class SeniorDoctor(Doctor):
    def get_role(self):
        return "SeniorDoctor"

    def approve_discharge(self):
        return True
