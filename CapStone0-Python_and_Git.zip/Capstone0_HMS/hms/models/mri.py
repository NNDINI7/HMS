from .lab_test import LabTest


class MRI(LabTest):
    def __init__(self, tid, patient=None, doctor=None, approved=False):
        super().__init__(tid, patient, doctor)
        self.approved = approved

    def price(self):
        return 6500

    def generate_report(self):
        return self.result or "body part, findings text"
