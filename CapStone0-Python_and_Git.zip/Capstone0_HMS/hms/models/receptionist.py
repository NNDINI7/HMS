"""Receptionist model."""

from .person import Person


class Receptionist(Person):
    def __init__(self, rid, name, age, phone, overtime=0):
        super().__init__(rid, name, age, phone)
        self.overtime = overtime

    def get_role(self):
        return "Receptionist"
