"""Ward and bed model."""


class Ward:
    def __init__(self, name, beds, charge):
        self.name = name
        self.beds = int(beds)
        self.charge = float(charge)
        self.occupied = 0
        self.cleaning = 0
        self.maintenance = 0

    def available(self):
        return self.beds - self.occupied - self.cleaning - self.maintenance

    def is_full(self):
        return self.available() <= 0

    def __len__(self):
        return self.occupied
