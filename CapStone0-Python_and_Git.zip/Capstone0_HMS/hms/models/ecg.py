from .lab_test import LabTest


class ECG(LabTest):
    def __init__(self, tid, patient=None, doctor=None):
        super().__init__(tid, patient, doctor)

    def price(self):
        return 300

    def generate_report(self):
        return self.result or "heart rate, rhythm"
