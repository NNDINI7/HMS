"""Patient model."""

from .person import Person


class Patient(Person):
    def __init__(self, pid, name, age, phone, blood_group="Unknown"):
        super().__init__(pid, name, age, phone)
        self.blood_group = blood_group
        self.status = "OPD"
        self.history = []
        self.allergies = []
        self.prescriptions = []
        self.doctor_id = None
        self.ward = None
        self.bed_id = None
        self.admission_date = None
        self.diet = None
        self.visitors = []
        self.followups = []
        self.ratings = set()

    def get_role(self):
        return "Patient"

    def add_history(self, text):
        self.history.append(text)

    @classmethod
    def from_string(cls, text):
        pid, name, age, phone, blood = [x.strip() for x in text.split(",")]
        return cls(pid, name, int(age), phone, blood)
