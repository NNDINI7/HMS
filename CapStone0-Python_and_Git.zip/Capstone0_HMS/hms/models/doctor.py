"""Doctor model."""

from .person import Person


class Doctor(Person):
    def __init__(self, did, name, age, phone, speciality, fee=500, slots=None):
        super().__init__(did, name, age, phone)
        self.speciality = speciality
        self.fee = float(fee)
        self.available_slots = slots or ["10:00", "11:00", "15:00"]
        self.leave_dates = []
        self.consultations = 0
        self.surgeries = 0
        self.ratings = []

    def get_role(self):
        return "Doctor"

    @property
    def average_rating(self):
        return sum(self.ratings) / len(self.ratings) if self.ratings else 0

    def __str__(self):
        return f"{self.pid} - Dr. {self.name} - {self.speciality}"
