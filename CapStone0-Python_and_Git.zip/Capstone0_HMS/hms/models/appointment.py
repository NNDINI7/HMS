"""Appointment model."""


class Appointment:
    def __init__(self, aid, pid, did, date, time):
        self.aid = aid
        self.pid = pid
        self.did = did
        self.date = date
        self.time = time
        self.status = "BOOKED"
        self.paid = 0.0
        self.followup = None

    def __str__(self):
        return f"{self.aid} | {self.pid} | {self.did} | {self.date} {self.time} | {self.status}"

    def __repr__(self):
        return f"Appointment({self.aid!r}, {self.pid!r}, {self.did!r})"
