"""Base person used by all people in the hospital."""

from abc import ABC, abstractmethod


class Person(ABC):
    def __init__(self, pid, name, age, phone):
        self.pid = pid
        self.name = name
        self.age = age
        self.phone = phone

    @abstractmethod
    def get_role(self):
        pass

    def get_details(self):
        return f"{self.pid} - {self.name} - Age: {self.age}"

    def __eq__(self, other):
        return isinstance(other, Person) and self.pid.upper() == other.pid.upper()

    def __str__(self):
        return f"{self.pid} - {self.name}"

    def __repr__(self):
        return f"{self.__class__.__name__}({self.pid!r}, {self.name!r})"
