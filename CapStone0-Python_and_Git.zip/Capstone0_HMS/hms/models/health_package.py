"""Health check-up package."""


class HealthPackage:
    DISCOUNTS = {"BASIC": 0.10, "EXECUTIVE": 0.15, "SENIOR CITIZEN": 0.20}

    def __init__(self, name):
        self.name = name
        self.items = []

    def add(self, item):
        self.items.append(item)

    def price(self):
        total = sum(x.price() for x in self.items)
        discount = self.DISCOUNTS.get(self.name.upper(), 0)
        return total * (1 - discount)
