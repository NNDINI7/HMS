"""Small seed data so the application starts ready for a demo."""

SEED_DATA = {
    "patients": [
        {"id": "P001", "name": "Anil Kumar", "age": 45, "phone": "9876543210", "blood": "O+"},
        {"id": "P002", "name": "Sneha Patil", "age": 65, "phone": "9876543211", "blood": "A+"},
        {"id": "P003", "name": "Rahul Sharma", "age": 34, "phone": "9876543212", "blood": "B+"},
        {"id": "P004", "name": "Priya Joshi", "age": 29, "phone": "9876543213", "blood": "AB+"},
        {"id": "P005", "name": "Vikas More", "age": 52, "phone": "9876543214", "blood": "O-"},
    ],
    "doctors": [
        {"id": "D001", "name": "Meera Rao", "age": 42, "phone": "9876500001", "speciality": "Cardiology", "fee": 800},
        {"id": "D002", "name": "Amit Shah", "age": 40, "phone": "9876500002", "speciality": "General", "fee": 600},
        {"id": "D003", "name": "Neha Jain", "age": 38, "phone": "9876500003", "speciality": "Neurology", "fee": 700},
    ],
    "nurses": [
        {"id": "N001", "name": "Riya", "age": 30, "phone": "9876500011", "shift": "Morning", "ward": "General"},
        {"id": "N002", "name": "Pooja", "age": 32, "phone": "9876500012", "shift": "Night", "ward": "ICU"},
    ],
    "wards": [
        {"name": "General", "beds": 10, "charge": 1000},
        {"name": "Private", "beds": 5, "charge": 3500},
        {"name": "ICU", "beds": 4, "charge": 8000},
    ],
    "ambulances": [
        {"id": "AM01", "kind": "Basic", "distance": 5},
        {"id": "AM02", "kind": "ALS", "distance": 8},
    ],
}
