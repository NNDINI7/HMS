import re

def valid_name(value):
    return bool(re.fullmatch(r"[A-Za-z][A-Za-z .]{1,39}", value.strip()))
