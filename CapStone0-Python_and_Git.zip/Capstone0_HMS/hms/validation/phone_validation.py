import re

def valid_phone(value):
    return bool(re.fullmatch(r"[6-9]\d{9}", value.strip()))
