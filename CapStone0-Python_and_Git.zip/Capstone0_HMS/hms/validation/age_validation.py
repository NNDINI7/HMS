def valid_age(value):
    try:
        return 0 <= int(value) <= 120
    except (TypeError, ValueError):
        return False
