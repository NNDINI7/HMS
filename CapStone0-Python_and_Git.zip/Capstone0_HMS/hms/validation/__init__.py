from .input_helper import get_id, get_name, get_age, get_phone
from .id_validation import valid_id
from .name_validation import valid_name
from .age_validation import valid_age
from .phone_validation import valid_phone
