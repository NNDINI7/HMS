from .id_validation import valid_id
from .name_validation import valid_name
from .phone_validation import valid_phone
from .age_validation import valid_age


def get_id(label, prefix):
    while True:
        value = input(f"{label} (e.g. {prefix}001): ").strip().upper()
        if valid_id(value, prefix):
            return value
        print(f"Invalid ID. Use {prefix}001 format.")


def get_name(label="Name"):
    while True:
        value = input(f"{label}: ").strip()
        if valid_name(value):
            return " ".join(value.split())
        print("Invalid name. Use letters and spaces only.")


def get_age():
    while True:
        value = input("Age (0-120): ").strip()
        if valid_age(value):
            return int(value)
        print("Age must be between 0 and 120.")


def get_phone():
    while True:
        value = input("Phone (10 digits): ").strip()
        if valid_phone(value):
            return value
        print("Invalid phone. Enter a valid 10-digit mobile number.")
