from .base_error import HospitalError

class ValidationError(HospitalError):
    pass
