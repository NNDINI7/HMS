from .base_error import HospitalError

class DoctorNotAvailableError(HospitalError):
    pass
