from .base_error import HospitalError

class AppointmentError(HospitalError):
    pass
