from .base_error import CityCareError, HospitalError
from .doctor_not_available import DoctorNotAvailableError
from .patient_not_found import PatientNotFoundError
from .bed_not_available import BedNotAvailableError
from .appointment_error import AppointmentError
from .billing_error import BillingError
from .validation_error import ValidationError
