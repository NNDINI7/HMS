from .base_error import HospitalError

class BillingError(HospitalError):
    pass
