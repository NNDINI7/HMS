class CityCareError(Exception):
    """Base error for CityCare."""


class HospitalError(CityCareError):
    pass
