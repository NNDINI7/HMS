from .base_error import HospitalError

class PatientNotFoundError(HospitalError):
    pass
