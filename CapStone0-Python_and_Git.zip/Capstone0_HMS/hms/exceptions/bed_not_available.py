from .base_error import HospitalError

class BedNotAvailableError(HospitalError):
    pass
