"""CityCare Hospital Management System."""
