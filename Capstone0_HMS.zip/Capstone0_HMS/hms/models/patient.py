#patient model

from .person import Person

class Patient(Person):
    def __init__(self, pid, name, age, phone, blood_group="Unknown"):
        super().__init__(pid, name, age, phone)
        self.blood_group = blood_group
        self.status = "OPD"
        self.history = []
        self.allergies = []
