#doctor model

from .person import Person

class Doctor(Person):
    def __init__(self, did, name, age, phone, speciality, fee=500):
        super().__init__(did, name, age, phone)
        self.speciality = speciality
        self.fee = fee
        self.leave_dates = []
