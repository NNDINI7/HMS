#medicine model

class Medicine:
    def __init__(self, name, price, stock=0):
        self.name = name
        self.price = price
        self.stock = stock
