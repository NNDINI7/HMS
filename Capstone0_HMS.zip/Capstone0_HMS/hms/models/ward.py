#ward model

class Ward:
    def __init__(self, name, beds, charge):
        self.name = name
        self.beds = beds
        self.charge = charge
        self.occupied = 0

    def available(self):
        return self.beds - self.occupied
