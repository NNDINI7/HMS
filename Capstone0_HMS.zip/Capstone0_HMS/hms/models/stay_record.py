#stay record model

class StayRecord:
    def __init__(self, ward, start, end=None):
        self.ward = ward
        self.start = start
        self.end = end
