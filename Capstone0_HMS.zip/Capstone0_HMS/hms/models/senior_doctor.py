#senior doctor model

from .doctor import Doctor

class SeniorDoctor(Doctor):
    def __init__(self, did, name, age, phone, speciality, fee=1000):
        super().__init__(did, name, age, phone, speciality, fee)
        self.approval_required = True
