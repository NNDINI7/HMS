#nurse model

from .person import Person

class Nurse(Person):
    def __init__(self, nid, name, age, phone, shift="Morning"):
        super().__init__(nid, name, age, phone)
        self.shift = shift
