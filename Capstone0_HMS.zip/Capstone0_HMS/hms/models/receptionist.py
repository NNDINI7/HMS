#receptionist model

from .person import Person

class Receptionist(Person):
    def __init__(self, rid, name, age, phone):
        super().__init__(rid, name, age, phone)
