#lab test model

class LabTest:
    def __init__(self, tid, name, price):
        self.tid = tid
        self.name = name
        self.price = price
        self.result = None

    def add_result(self, result):
        self.result = result
