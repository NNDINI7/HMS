# """ This is the Ambulance model."""

class Ambulance:
    def __init__(self, aid, kind="Basic", rate=500):
        self.aid = aid
        self.kind = kind
        self.rate = rate
        self.available = True
