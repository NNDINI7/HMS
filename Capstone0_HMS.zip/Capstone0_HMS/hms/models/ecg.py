#ecg model

from .lab_test import LabTest

class ECG(LabTest):
    def __init__(self, tid, price=1200):
        super().__init__(tid, "ECG", price)
