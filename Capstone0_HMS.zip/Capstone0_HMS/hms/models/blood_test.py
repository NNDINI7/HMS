#blood test model
from .lab_test import LabTest

class BloodTest(LabTest):
    def __init__(self, tid, price=500):
        super().__init__(tid, "Blood Test", price)
