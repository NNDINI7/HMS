#x-ray model

from .lab_test import LabTest

class XRay(LabTest):
    def __init__(self, tid, price=800):
        super().__init__(tid, "X-Ray", price)
