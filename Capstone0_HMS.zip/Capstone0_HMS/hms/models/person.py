#person model

class Person:
    def __init__(self, pid, name, age, phone):
        self.pid = pid
        self.name = name
        self.age = age
        self.phone = phone

    def get_details(self):
        return f"{self.pid} - {self.name} - {self.age}"
