#Bill model

class Bill:
    def __init__(self, bid, pid):
        self.bid = bid
        self.pid = pid
        self.items = []
        self.paid = 0

    def add_item(self, name, amount):
        self.items.append((name, float(amount)))

    def total(self):
        return sum(amount for _, amount in self.items)

    def balance(self):
        return self.total() - self.paid
