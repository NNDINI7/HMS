#Appointment model

class Appointment:
    def __init__(self, aid, pid, did, date, time):
        self.aid = aid
        self.pid = pid
        self.did = did
        self.date = date
        self.time = time
        self.status = "BOOKED"
