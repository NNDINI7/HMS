#mri model

from .lab_test import LabTest

class MRI(LabTest):
    def __init__(self, tid, price=6500):
        super().__init__(tid, "MRI", price)
