#surgery model

class Surgery:
    def __init__(self, sid, pid, kind, date, time):
        self.sid = sid
        self.pid = pid
        self.kind = kind
        self.date = date
        self.time = time
