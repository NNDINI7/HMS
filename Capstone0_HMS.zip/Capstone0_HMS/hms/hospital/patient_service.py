# """This is a cause to Patient operations.If there is any error in patient operations, this exception will be raised."""

class PatientService:
    def __init__(self, hospital):
        self.hospital = hospital

    def admit(self, pid):
        patient = self.hospital.patients[pid]
        patient.status = "IPD"
        return patient
