# """ This is the main hospital class.It contains the details of the hospital, including its name, patients, doctors, nurses, appointments, and bills. It also provides methods to add patients and doctors to the hospital."""

class Hospital:
    def __init__(self, name="CityCare Hospital"):
        self.name = name
        self.patients = {}
        self.doctors = {}
        self.nurses = {}
        self.appointments = {}
        self.bills = {}

    def add_patient(self, patient):
        self.patients[patient.pid] = patient

    def add_doctor(self, doctor):
        self.doctors[doctor.pid] = doctor
