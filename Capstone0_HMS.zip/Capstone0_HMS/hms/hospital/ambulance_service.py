# """This is a cause to Ambulance operations.If there is any error in ambulance operations, this exception will be raised."""

class AmbulanceService:
    def __init__(self, hospital):
        self.hospital = hospital

    def book(self, pid, ambulance):
        from .billing_service import BillingService
        BillingService(self.hospital).add_charge(pid, "Ambulance", ambulance.rate)
        ambulance.available = False
        return ambulance
