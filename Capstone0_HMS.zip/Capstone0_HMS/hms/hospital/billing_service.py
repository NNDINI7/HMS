# """Billing operations."""

class BillingService:
    def __init__(self, hospital):
        self.hospital = hospital

    def add_charge(self, pid, name, amount):
        bill = self.hospital.bills.get(pid)
        if bill is None:
            from hms.models.bill import Bill
            bill = Bill(f"B{len(self.hospital.bills)+1:03d}", pid)
            self.hospital.bills[pid] = bill
        bill.add_item(name, amount)
        return bill
