# """Appointment operations.It contains the details of the appointment, including its id, patient id, doctor id, date, time, and status. It also provides methods to book an appointment and check if a doctor is free at a given date and time."""

class AppointmentService:
    def __init__(self, hospital):
        self.hospital = hospital

    def is_free(self, did, date, time):
        for ap in self.hospital.appointments.values():
            if ap.did == did and ap.date == date and ap.time == time and ap.status == "BOOKED":
                return False
        return True
