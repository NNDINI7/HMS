# """ This is a cause to Lab booking operations.If there is any error in lab booking, this exception will be raised."""

class LabService:
    def __init__(self, hospital):
        self.hospital = hospital

    def book(self, pid, test):
        from .billing_service import BillingService
        BillingService(self.hospital).add_charge(pid, f"Test - {test.name}", test.price)
        return test
