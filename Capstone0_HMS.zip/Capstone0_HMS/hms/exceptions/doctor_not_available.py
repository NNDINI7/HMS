# """This is a cause to Doctor not available error.If there is any error in doctor availability, this exception will be raised."""

from .base_error import CityCareError

class DoctorNotAvailableError(CityCareError):
    pass
