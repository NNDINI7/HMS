# """This is a cause to Billing error.If there is any error in billing, this exception will be raised."""

from .base_error import CityCareError

class BillingError(CityCareError):
    pass
