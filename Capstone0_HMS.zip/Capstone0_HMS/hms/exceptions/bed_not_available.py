# """This is a cause to Bed not available error.If there is any error in bed availability, this exception will be raised."""

from .base_error import CityCareError

class BedNotAvailableError(CityCareError):
    pass
