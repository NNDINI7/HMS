# """This is the base CityCare error.If there is any error in CityCare, this exception will be raised."""

class CityCareError(Exception):
    pass
