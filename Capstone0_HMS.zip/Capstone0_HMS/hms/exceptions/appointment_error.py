# """This is a cause to Appointment error.If there is any error in appointment, this exception will be raised."""

from .base_error import CityCareError

class AppointmentError(CityCareError):
    pass
