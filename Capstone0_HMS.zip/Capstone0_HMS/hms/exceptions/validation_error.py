# """This is a cause to Validation error.If there is any error in validation, this exception will be raised."""

from .base_error import CityCareError

class ValidationError(CityCareError):
    pass
