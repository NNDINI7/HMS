# """This is a cause to Patient not found error.If there is any error in patient lookup, this exception will be raised."""

from .base_error import CityCareError

class PatientNotFoundError(CityCareError):
    pass
