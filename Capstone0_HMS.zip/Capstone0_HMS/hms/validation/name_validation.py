"""Name checks."""
import re

def valid_name(value):
    return bool(re.fullmatch(r"[A-Za-z .]+", value.strip()))
