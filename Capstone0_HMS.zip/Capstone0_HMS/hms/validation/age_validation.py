"""Age checks."""

def valid_age(value):
    try:
        return 0 <= int(value) <= 120
    except ValueError:
        return False
