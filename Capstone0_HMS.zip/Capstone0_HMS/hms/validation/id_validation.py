"""ID checks."""
import re

def valid_id(value, prefix):
    return bool(re.fullmatch(prefix + r"\d{3}", value.strip().upper()))
