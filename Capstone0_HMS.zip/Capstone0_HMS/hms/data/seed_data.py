#simple sample data added for verification.

#eg Patient id, name and age, ph no., blood group
SEED_DATA = {
    "patients": [
        {"id": "P001", "name": "Anil Kumar", "age": 45, "phone": "9876543210", "blood": "O+"},
        {"id": "P002", "name": "Sneha Patil", "age": 65, "phone": "9876543211", "blood": "A+"},
        {"id": "P003", "name": "Rahul Sharma", "age": 34, "phone": "9876543212", "blood": "B+"},
    ],#for dr id, name, speciality, fee
    "doctors": [
        {"id": "D001", "name": "Meera Rao", "speciality": "Cardiology", "fee": 800},
        {"id": "D002", "name": "Amit Shah", "speciality": "General", "fee": 600},
    ],#for nurse id, name, shift
    "nurses": [
        {"id": "N001", "name": "Neha Patil", "shift": "Morning"},
        {"id": "N002", "name": "Kiran Joshi", "shift": "Night"},
    ],#for ward name, beds, charge
    "wards": [
        {"name": "General", "beds": 10, "charge": 1000},
        {"name": "Private", "beds": 5, "charge": 3500},
        {"name": "ICU", "beds": 4, "charge": 8000},
    ],
}
